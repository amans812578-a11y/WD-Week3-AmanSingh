/*
 WEEK 3 ASSIGNMENT: JAVASCRIPT FUNDAMENTALS
 Student: Aman Singh
 All outputs use console.log(). No DOM manipulation or event handling.
*/

// TASK 1: JAVASCRIPT BASICS (15 MARKS)
console.log("========== TASK 1: JAVASCRIPT BASICS ==========");
console.log("Welcome to JavaScript Fundamentals!");
console.log("This is my Week 3 assignment.");
// Single-line comment: this is a basic JavaScript statement.
console.log("JavaScript makes websites interactive.");
/*
 Multi-line comment:
 This JavaScript file is connected to index.html
 using the script tag.
*/
let studentName = "Aman Singh";
let courseName = "BCA";
console.log("Student:", studentName);
console.log("Course:", courseName);

// TASK 2: VARIABLES AND DATA TYPES (20 MARKS)
console.log("\\n========== TASK 2: VARIABLES AND DATA TYPES ==========");
let city;
city = "Ghazipur";
console.log("Declared and assigned city:", city);
let semester = 5;
semester = 6; // Variable reassignment
console.log("Semester:", semester);
const collegeName = "JNM College for Advance Studies and Technology";
console.log("College:", collegeName);

let fullName = "Aman Singh";       // String
let totalMarks = 82;               // Number
let isStudent = true;              // Boolean
let result;                        // Undefined
let middleName = null;             // Null
console.log("String:", fullName, "| Type:", typeof fullName);
console.log("Number:", totalMarks, "| Type:", typeof totalMarks);
console.log("Boolean:", isStudent, "| Type:", typeof isStudent);
console.log("Undefined:", result, "| Type:", typeof result);
console.log("Null:", middleName, "| Type:", typeof middleName);
console.log("Type of 100:", typeof 100);
console.log("Type of 10.5:", typeof 10.5);
console.log("Type of false:", typeof false);
console.log("Note: typeof null returns object in JavaScript.");

// TASK 3: OPERATORS (20 MARKS)
console.log("\\n========== TASK 3: OPERATORS ==========");
let firstNumber = 20;
let secondNumber = 5;
// Arithmetic operators
console.log("Addition:", firstNumber + secondNumber);
console.log("Subtraction:", firstNumber - secondNumber);
console.log("Multiplication:", firstNumber * secondNumber);
console.log("Division:", firstNumber / secondNumber);
console.log("Remainder:", firstNumber % secondNumber);
console.log("Exponent:", firstNumber ** 2);
// Assignment operators
let score = 10;
score += 5;
console.log("After += 5:", score);
score -= 2;
console.log("After -= 2:", score);
score *= 2;
console.log("After *= 2:", score);
score /= 2;
console.log("After /= 2:", score);
// Comparison operators
console.log("20 > 5:", firstNumber > secondNumber);
console.log("20 < 5:", firstNumber < secondNumber);
console.log("20 === 20:", firstNumber === 20);
console.log("20 !== 5:", firstNumber !== secondNumber);
console.log("20 >= 20:", firstNumber >= 20);
// Logical operators
let hasIdCard = true;
let attendanceEligible = true;
console.log("AND:", hasIdCard && attendanceEligible);
console.log("OR:", hasIdCard || attendanceEligible);
console.log("NOT:", !hasIdCard);
// Increment and decrement
let counter = 4;
counter++;
console.log("After increment:", counter);
counter--;
console.log("After decrement:", counter);

// TASK 4: CONDITIONAL STATEMENTS (20 MARKS)
console.log("\\n========== TASK 4: CONDITIONAL STATEMENTS ==========");
// if: positive number
let numberToCheck = 12;
if (numberToCheck > 0) {
  console.log(numberToCheck, "is positive.");
}
// if...else: even or odd
let evenOddNumber = 7;
if (evenOddNumber % 2 === 0) {
  console.log(evenOddNumber, "is even.");
} else {
  console.log(evenOddNumber, "is odd.");
}
// else if: positive, negative or zero
let valueToCheck = -8;
if (valueToCheck > 0) {
  console.log("The number is positive.");
} else if (valueToCheck < 0) {
  console.log("The number is negative.");
} else {
  console.log("The number is zero.");
}
// Nested if: age and ID eligibility
let personAge = 20;
let hasIdentityCard = true;
if (personAge >= 18) {
  if (hasIdentityCard) {
    console.log("Eligible: age and ID requirements passed.");
  } else {
    console.log("Not eligible: please bring an identity card.");
  }
} else {
  console.log("Not eligible: minimum age is 18.");
}
// Greater of two numbers
let numberA = 45;
let numberB = 32;
if (numberA > numberB) {
  console.log("Greater number:", numberA);
} else if (numberB > numberA) {
  console.log("Greater number:", numberB);
} else {
  console.log("Both numbers are equal.");
}
// Greatest of three numbers
let numberX = 18, numberY = 64, numberZ = 41;
if (numberX >= numberY && numberX >= numberZ) {
  console.log("Greatest of three:", numberX);
} else if (numberY >= numberX && numberY >= numberZ) {
  console.log("Greatest of three:", numberY);
} else {
  console.log("Greatest of three:", numberZ);
}
// Grade based on marks
let examMarks = 86;
if (examMarks >= 90) {
  console.log("Grade: A+");
} else if (examMarks >= 80) {
  console.log("Grade: A");
} else if (examMarks >= 70) {
  console.log("Grade: B");
} else if (examMarks >= 60) {
  console.log("Grade: C");
} else if (examMarks >= 40) {
  console.log("Grade: D");
} else {
  console.log("Grade: Fail");
}

// TASK 5: LOOPS (20 MARKS)
console.log("\\n========== TASK 5: LOOPS ==========");
// for loop: numbers 1 to 10
console.log("Numbers from 1 to 10:");
for (let i = 1; i <= 10; i++) console.log(i);
// Even numbers
console.log("Even numbers from 1 to 20:");
for (let i = 1; i <= 20; i++) if (i % 2 === 0) console.log(i);
// Odd numbers
console.log("Odd numbers from 1 to 20:");
for (let i = 1; i <= 20; i++) if (i % 2 !== 0) console.log(i);
// Multiplication table
let tableNumber = 5;
console.log("Multiplication table of", tableNumber);
for (let i = 1; i <= 10; i++) console.log(tableNumber + " x " + i + " = " + tableNumber * i);
// Sum of numbers 1 to 10
let sum = 0;
for (let i = 1; i <= 10; i++) sum += i;
console.log("Sum from 1 to 10:", sum);
// while loop
console.log("While loop - numbers 1 to 5:");
let whileCounter = 1;
while (whileCounter <= 5) {
  console.log(whileCounter);
  whileCounter++;
}
// do...while loop
console.log("Do...while loop - numbers 1 to 5:");
let doCounter = 1;
do {
  console.log(doCounter);
  doCounter++;
} while (doCounter <= 5);
// Reverse order using decrement
console.log("Reverse order from 10 to 1:");
for (let i = 10; i >= 1; i--) console.log(i);

// TASK 6: JAVASCRIPT PRACTICE PROGRAMS (5 MARKS)
// Practice 1: total and average marks
console.log("\\n========== TASK 6: PRACTICE PROGRAMS ==========");
let englishMarks = 78, computerMarks = 92, mathsMarks = 85;
let total = englishMarks + computerMarks + mathsMarks;
let average = total / 3;
console.log("Program 1 - Total:", total, "Average:", average);
// Practice 2: simple interest
let principal = 5000, rate = 5, time = 2;
let simpleInterest = (principal * rate * time) / 100;
console.log("Program 2 - Simple interest:", simpleInterest);
// Practice 3: voting eligibility
let votingAge = 19;
if (votingAge >= 18) console.log("Program 3 - Eligible to vote.");
else console.log("Program 3 - Not eligible to vote.");
// Practice 4: factorial using a loop
let factorialNumber = 5, factorial = 1;
for (let i = 1; i <= factorialNumber; i++) factorial *= i;
console.log("Program 4 - Factorial of", factorialNumber, "is", factorial);
// Practice 5: leap year check
let year = 2028;
if ((year % 400 === 0) || (year % 4 === 0 && year % 100 !== 0)) {
  console.log("Program 5 -", year, "is a leap year.");
} else {
  console.log("Program 5 -", year, "is not a leap year.");
}
// Practice 6: countdown with while loop
console.log("Program 6 - Countdown:");
let countdown = 5;
while (countdown >= 1) {
  console.log(countdown);
  countdown--;
}
console.log("Countdown complete.");
console.log("\\n========== ALL WEEK 3 TASKS COMPLETED ==========");
