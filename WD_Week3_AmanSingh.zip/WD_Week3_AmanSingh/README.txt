WEEK 3 - JAVASCRIPT FUNDAMENTALS ASSIGNMENT
Student: Aman Singh

FILES
- index.html: HTML page connected to JavaScript.
- script.js: All six assignment tasks in one JavaScript file.
- README.txt: Setup and submission instructions.

RUN IN VS CODE
1. Extract WD_Week3_AmanSingh.zip.
2. Open the extracted folder in Visual Studio Code.
3. Open index.html.
4. Right-click and select Open with Live Server (install Live Server extension if needed).
5. In the browser press F12 and open the Console tab to see all outputs.

ALTERNATIVE
Install Node.js, open the VS Code terminal in this folder, and run:
node script.js

TASK COVERAGE
Task 1: JavaScript syntax, console.log(), single-line and multi-line comments, HTML linking and basic statements.
Task 2: let, const, declaration, assignment, String, Number, Boolean, undefined, null and typeof.
Task 3: Arithmetic, assignment, comparison, logical, increment and decrement operators.
Task 4: if, if...else, else if, nested if, positive/negative/zero, even/odd, age eligibility, greatest numbers and grades.
Task 5: for, while, do...while, conditions, increment/decrement, 1-10, even/odd, multiplication table, sum and reverse order.
Task 6: Six practice programs combining variables, data types, operators, conditions and loops.

The assignment says not to use DOM manipulation or event handling. This project follows that instruction and displays output with console.log().
Upload the complete ZIP to Google Drive, set access to Anyone with the link / Viewer, and submit the Drive link.
